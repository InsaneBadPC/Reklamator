# Design Brainstorm - IT & AI Milovice Web

## Vybraný Designový Přístup: Futuristický Minimalizmus s Technologickou Elegancí

### Design Movement
**Futuristic Minimalism** - Kombinace čistého, minimalistického designu s prvky cyberpunk estetiky. Zaměřuje se na funkčnost, jasnost a moderní technologické pocity bez přepychu.

### Core Principles
1. **Funkční Elegance** - Každý prvek má jasný účel; design slouží obsahu, ne naopak
2. **Vysoký Kontrast** - Tmavé pozadí s jasně nasycenými barvami pro maximální viditelnost a moderní vzhled
3. **Technologická Přítomnost** - Subtilní animace, gradientu a efekty, které evokují budoucnost
4. **Srozumitelnost** - Přestože je design moderní, vše je intuitivní pro běžné uživatele

### Color Philosophy
- **Primární barva:** Elektricky modrá (`#0066FF` nebo `#00D9FF`) - symbolizuje technologii, důvěru a energii
- **Sekundární barva:** Neonově zelená (`#00FF88`) - akcentuje důležité prvky a interakce
- **Pozadí:** Tmavě modrá/šedá (`#0F1419`) - profesionální, moderní, snižuje únavu očí
- **Text:** Bílá a světle šedá pro maximální kontrast
- **Akcenty:** Fialová a růžová pro speciální prvky

### Layout Paradigm
- **Asymetrické sekce** - Služby nejsou v pravidelné mřížce, ale v dynamickém rozložení
- **Vertikální tok** - Obsah teče přirozeně dolů se strategickými pauzami
- **Karty s hloubkou** - Služby jsou prezentovány jako interaktivní karty s efektem hloubky (shadow, hover lift)
- **Diagonální prvky** - Subtilní diagonální linie a tvary pro dynamiku

### Signature Elements
1. **Glowing Borders** - Karty mají jemný, svítící okraj, který se aktivuje při hoveru
2. **Gradient Backgrounds** - Subtilní gradientu v kartách a sekcích
3. **Animated Icons** - Ikony se animují při interakci (rotace, pulse, glow)
4. **Expandable Cards** - Služby se rozbalují s plynulou animací, odhalující praktické příklady

### Interaction Philosophy
- **Hover = Anticipation** - Při najetí myší se karta lehce zvedne a začne svítit
- **Click = Revelation** - Kliknutí odhalí praktické příklady a detaily
- **Micro-interactions** - Každá interakce má malou, příjemnou animaci
- **Feedback** - Uživatel vždy ví, co se děje (loading, success, error)

### Animation Guidelines
- **Duration:** 300-500ms pro plynulé, ale rychlé animace
- **Easing:** `cubic-bezier(0.4, 0, 0.2, 1)` pro přirozené pohyby
- **Hover Effects:** Karty se zvedají (transform: translateY), okraje svítí (box-shadow)
- **Expand Animation:** Obsah se rozbaluje s opacity a height animací
- **Icon Animation:** Ikony se otáčejí nebo pulzují (scale, rotate)

### Typography System
- **Display Font:** `Poppins` (bold, 700) - Nadpisy, hero text - moderní, geometrický
- **Body Font:** `Inter` (regular, 400) - Tělo textu - čitelné, neutrální
- **Accent Font:** `Courier Prime` (monospace) - Technické detaily, kódy - futuristické
- **Hierarchy:**
  - H1: Poppins 48px, bold, primary color
  - H2: Poppins 32px, bold, primary color
  - H3: Poppins 24px, semi-bold, secondary color
  - Body: Inter 16px, regular, text color
  - Small: Inter 14px, regular, muted color

## Implementační Poznámky
- Tmavý motiv jako výchozí (defaultTheme="dark")
- Elektricky modrá a neonově zelená jako primární barvy
- Glowing efekty a animace pro interaktivní prvky
- Praktické příklady v rozbalovacích kartách
- Srozumitelný, přátelský text bez technického žargonu
