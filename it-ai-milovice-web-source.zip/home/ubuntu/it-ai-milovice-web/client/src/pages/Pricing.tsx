import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Zap, Check } from "lucide-react";

/**
 * Pricing - Stránka s ceníkem
 * Design: Futuristický minimalizmus s tmavým motivem
 * - Ceny pro domácnosti
 * - Ceny pro podnikatele
 * - FAQ
 */
export default function Pricing() {
  const householdPlans = [
    {
      name: "Konzultace",
      subtitle: "Diagnóza a návrh řešení",
      price: "Zdarma",
      features: [
        "Analýza problému",
        "Návrh řešení",
        "Bez závazku",
      ],
    },
    {
      name: "Hodinová sazba",
      subtitle: "Za jednu hodinu práce",
      price: "400 Kč",
      priceNote: "/hod",
      features: [
        "Flexibilní čas",
        "Různé úkoly",
        "Bez minimálního počtu hodin",
      ],
      highlighted: true,
    },
    {
      name: "Balíček Domácí údržba",
      subtitle: "Měsíční balíček",
      price: "1 500 Kč",
      priceNote: "/měsíc",
      features: [
        "3 hodiny údržby měsíčně",
        "Prioritní podpora",
        "Slevy na další služby",
      ],
    },
  ];

  const entrepreneurPlans = [
    {
      name: "Konzultace",
      subtitle: "Analýza a strategie",
      price: "Zdarma",
      features: [
        "Analýza potřeb",
        "Návrh řešení",
        "Bez závazku",
      ],
    },
    {
      name: "Hodinová sazba",
      subtitle: "Za jednu hodinu práce",
      price: "600 Kč",
      priceNote: "/hod",
      features: [
        "Flexibilní čas",
        "Různé úkoly",
        "Bez minimálního počtu hodin",
      ],
      highlighted: true,
    },
    {
      name: "Balíček Digitální transformace",
      subtitle: "Komplexní řešení",
      price: "Na nabídku",
      features: [
        "Individuální přístup",
        "Dlouhodobá podpora",
        "Školení zaměstnanců",
      ],
    },
  ];

  const faqs = [
    {
      question: "Jsou ceny bez DPH?",
      answer: "Všechny ceny jsou uvedeny bez DPH. Nejsem plátce DPH, takže cena je pro vás konečná.",
    },
    {
      question: "Kolik stojí doprava?",
      answer: "Doprava není zahrnuta v ceně. Bude domluvena individuálně podle lokality.",
    },
    {
      question: "Jaká je minimální doba služby?",
      answer: "Minimální doba je 1 hodina. Konzultace jsou bezplatné a bez minimální doby.",
    },
    {
      question: "Nabízíte slevy?",
      answer: "Ano, nabízíme slevy na dlouhodobé smlouvy a balíčky služeb. Kontaktujte nás.",
    },
    {
      question: "Jaké jsou podmínky platby?",
      answer: "Platba je možná převodem, hotovostí nebo kartou. Fakturu vystavíme po dokončení práce.",
    },
    {
      question: "Co když nejsem spokojen?",
      answer: "Vaše spokojenost je naší prioritou. Pokud nejste spokojeni, budeme problém řešit.",
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 z-50 bg-background/80 backdrop-blur-sm">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="heading text-xl font-bold">IT & AI Milovice</h1>
            </a>
          </Link>
          <Link href="/contact">
            <a>
              <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                Kontakt
              </Button>
            </a>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="container py-16">
        <h2 className="heading text-4xl font-bold mb-4">Ceník</h2>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Nabízíme kvalitní služby za jasně stanovené ceny bez jakýchkoliv skrytých poplatků.
        </p>
      </section>

      {/* Household Plans */}
      <section className="container py-12">
        <h3 className="heading text-2xl font-bold mb-8">Služby pro domácnosti</h3>
        <p className="text-muted-foreground mb-8">
          Poskytujeme IT podporu pro domácnosti za srozumitelné a transparentní ceny.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {householdPlans.map((plan, idx) => (
            <div
              key={idx}
              className={`glow-card p-8 transition-all duration-300 ${
                plan.highlighted
                  ? "border-blue-400/60 ring-1 ring-blue-500/20"
                  : "border-blue-500/20"
              }`}
            >
              <h4 className="heading text-lg font-bold mb-1">{plan.name}</h4>
              <p className="text-sm text-muted-foreground mb-6">{plan.subtitle}</p>
              <div className="mb-6">
                <div className="text-3xl font-bold text-blue-400">
                  {plan.price}
                  {plan.priceNote && <span className="text-lg text-muted-foreground">{plan.priceNote}</span>}
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              <Link href="/contact">
                <a>
                  <Button
                    variant={plan.highlighted ? "default" : "outline"}
                    className="w-full"
                  >
                    Více informací
                  </Button>
                </a>
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Entrepreneur Plans */}
      <section className="container py-12">
        <h3 className="heading text-2xl font-bold mb-8">Služby pro podnikatele</h3>
        <p className="text-muted-foreground mb-8">
          Nabízíme individuálně nastavené ceny pro digitální transformaci a růst vaší firmy.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {entrepreneurPlans.map((plan, idx) => (
            <div
              key={idx}
              className={`glow-card p-8 transition-all duration-300 ${
                plan.highlighted
                  ? "border-blue-400/60 ring-1 ring-blue-500/20"
                  : "border-blue-500/20"
              }`}
            >
              <h4 className="heading text-lg font-bold mb-1">{plan.name}</h4>
              <p className="text-sm text-muted-foreground mb-6">{plan.subtitle}</p>
              <div className="mb-6">
                <div className="text-3xl font-bold text-blue-400">
                  {plan.price}
                  {plan.priceNote && <span className="text-lg text-muted-foreground">{plan.priceNote}</span>}
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              <Link href="/contact">
                <a>
                  <Button
                    variant={plan.highlighted ? "default" : "outline"}
                    className="w-full"
                  >
                    Více informací
                  </Button>
                </a>
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="container py-12">
        <h3 className="heading text-2xl font-bold mb-8">Často kladené otázky</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {faqs.map((faq, idx) => (
            <div key={idx} className="glow-card border-blue-500/20 p-6">
              <h4 className="heading font-bold mb-3">{faq.question}</h4>
              <p className="text-muted-foreground text-sm">{faq.answer}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container py-16">
        <div className="glow-card border-green-500/30 hover:border-green-400/60 p-12 text-center">
          <h3 className="heading text-2xl font-bold mb-4">Máte otázky k ceníku?</h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Neváhejte nás kontaktovat a domluvit si bezplatnou konzultaci. Rádi vám vše
            podrobně vysvětlíme a připravíme nabídku na míru.
          </p>
          <Link href="/contact">
            <a>
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Kontaktujte mě
              </Button>
            </a>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-16 py-8">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="heading font-bold mb-4">IT & AI Milovice</h4>
              <p className="text-sm text-muted-foreground">
                Vaš partner pro digitální transformaci
              </p>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Navigace</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/">
                    <a className="hover:text-foreground transition-colors">Domů</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <a className="hover:text-foreground transition-colors">Služby</a>
                  </Link>
                </li>
                <li>
                  <Link href="/pricing">
                    <a className="hover:text-foreground transition-colors">Ceník</a>
                  </Link>
                </li>
                <li>
                  <Link href="/contact">
                    <a className="hover:text-foreground transition-colors">Kontakt</a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Kontakt</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="tel:+420731253101" className="hover:text-foreground transition-colors">
                    731 253 101
                  </a>
                </li>
                <li>
                  <a href="mailto:petr.lukes89@gmail.com" className="hover:text-foreground transition-colors">
                    petr.lukes89@gmail.com
                  </a>
                </li>
                <li>
                  <a href="https://wa.me/420731253101" className="hover:text-foreground transition-colors">
                    WhatsApp
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Právní</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Zásady ochrany
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Podmínky použití
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 IT & AI Milovice. Všechna práva vyhrazena.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
