import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Zap, CheckCircle } from "lucide-react";

/**
 * Process - Stránka s popisem procesu spolupráce
 * Design: Futuristický minimalizmus s tmavým motivem
 * - 4 kroky procesu
 * - Detailní popis každého kroku
 * - CTA pro kontakt
 */
export default function Process() {
  const steps = [
    {
      number: 1,
      title: "Nezávazná poptávka",
      description: "Ozvěte se nám telefonicky, e-mailem nebo přes WhatsApp. Popište nám svůj problém nebo potřebu co nejpodrobněji. Nemějte obavy z technických termínů – jsme tu od toho, abychom vám rozuměli.",
      highlights: [
        "Bez závazku",
        "Bez skrytých poplatků",
        "Bez tlaku",
      ],
    },
    {
      number: 2,
      title: "Bezplatná konzultace",
      description: "Domluvíme si osobní nebo online schůzku. Během ní probereme, co přesně potřebujete, jaké budou náklady a časový rámec realizace. Vše nezávazně a transparentně.",
      highlights: [
        "Osobní nebo online",
        "Bez nátlaku",
        "Jasné vysvětlení",
      ],
    },
    {
      number: 3,
      title: "Realizace řešení",
      description: "Po vzájemné dohodě se pustíme do práce. O každém kroku vás budeme informovat a vše srozumitelně vysvětlovat. Budete mít vždy přehled o tom, co se děje a proč.",
      highlights: [
        "Transparentní komunikace",
        "Pravidelné aktualizace",
        "Vaše pohodlí na prvním místě",
      ],
    },
    {
      number: 4,
      title: "Dlouhodobá podpora a partnerství",
      description: "Naše práce nekončí vyřešením problému. Jsme tu pro vás i nadále s nabídkou následné podpory, školení a poradenství. Stáváme se vaším dlouhodobým partnerem ve světě technologií.",
      highlights: [
        "Dostupnost",
        "Školení",
        "Dlouhodobé partnerství",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 z-50 bg-background/80 backdrop-blur-sm">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="heading text-xl font-bold">IT & AI Milovice</h1>
            </a>
          </Link>
          <Link href="/contact">
            <a>
              <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                Kontakt
              </Button>
            </a>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="container py-16">
        <h2 className="heading text-4xl font-bold mb-4">Jak probíhá spolupráce</h2>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Náš proces je jednoduchý, transparentní a navržený tak, aby vás provedl od úvodního
          kontaktu až po zajištění dlouhodobé podpory.
        </p>
      </section>

      {/* Process Overview */}
      <section className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-16">
          {steps.map((step, idx) => (
            <div key={idx} className="relative">
              <div className="glow-card border-blue-500/20 p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-lg">{step.number}</span>
                </div>
                <h3 className="heading font-bold text-sm">{step.title}</h3>
              </div>
              {idx < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-2 w-4 h-0.5 bg-gradient-to-r from-blue-500 to-transparent"></div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Detailed Steps */}
      <section className="container py-12">
        <h3 className="heading text-2xl font-bold mb-12">Detaily procesu</h3>
        <div className="space-y-8">
          {steps.map((step, idx) => (
            <div key={idx} className="glow-card border-blue-500/20 p-8">
              <div className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                    <span className="text-white font-bold text-lg">{step.number}</span>
                  </div>
                </div>
                <div className="flex-grow">
                  <h4 className="heading text-xl font-bold mb-3">{step.title}</h4>
                  <p className="text-muted-foreground mb-6">{step.description}</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {step.highlights.map((highlight, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                        <span className="text-sm">{highlight}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container py-16">
        <div className="glow-card border-green-500/30 hover:border-green-400/60 p-12 text-center">
          <h3 className="heading text-2xl font-bold mb-4">Jste připraveni na změnu?</h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Ozvěte se nám ještě dnes a domluvte si bezplatnou a nezávaznou konzultaci.
            Společně najdeme to nejlepší řešení pro vás.
          </p>
          <Link href="/contact">
            <a>
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Kontaktujte mě
              </Button>
            </a>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-16 py-8">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="heading font-bold mb-4">IT & AI Milovice</h4>
              <p className="text-sm text-muted-foreground">
                Vaš partner pro digitální transformaci
              </p>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Navigace</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/">
                    <a className="hover:text-foreground transition-colors">Domů</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <a className="hover:text-foreground transition-colors">Služby</a>
                  </Link>
                </li>
                <li>
                  <Link href="/process">
                    <a className="hover:text-foreground transition-colors">Jak to funguje</a>
                  </Link>
                </li>
                <li>
                  <Link href="/contact">
                    <a className="hover:text-foreground transition-colors">Kontakt</a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Kontakt</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="tel:+420731253101" className="hover:text-foreground transition-colors">
                    731 253 101
                  </a>
                </li>
                <li>
                  <a href="mailto:petr.lukes89@gmail.com" className="hover:text-foreground transition-colors">
                    petr.lukes89@gmail.com
                  </a>
                </li>
                <li>
                  <a href="https://wa.me/420731253101" className="hover:text-foreground transition-colors">
                    WhatsApp
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Právní</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Zásady ochrany
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Podmínky použití
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 IT & AI Milovice. Všechna práva vyhrazena.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
