import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  Mail,
  Shield,
  HardDrive,
  Zap,
  BarChart3,
  Lock,
  Smartphone,
  AlertTriangle,
  MessageSquare,
  Users,
  Cloud,
  Settings,
  ArrowRight,
} from "lucide-react";

/**
 * Services - Stránka se všemi službami
 * Design: Futuristický minimalizmus s tmavým motivem
 * - Detailní popis každé služby
 * - Praktické příklady
 * - CTA pro kontakt
 */
export default function Services() {
  const services = [
    {
      title: "Pomoc s e-mailem a komunikací",
      description: "Nastavíme vám e-mail, vysvětlíme jak ho bezpečně používat",
      icon: <Mail className="w-8 h-8" />,
      category: "Domácnosti",
      details: [
        "Nastavení e-mailu na telefonu a počítači",
        "Jak poznat podvodný e-mail a vyhnout se mu",
        "Bezpečné sdílení fotek s rodinou přes e-mail",
        "Organizace e-mailů do složek",
      ],
    },
    {
      title: "Nákupy online bezpečně",
      description: "Naučíme vás bezpečně nakupovat na internetu",
      icon: <Shield className="w-8 h-8" />,
      category: "Domácnosti",
      details: [
        "Jak poznat bezpečný e-shop a ověřit si ho",
        "Bezpečné platby kartou a přes PayPal",
        "Ochrana před podvody a padělky",
        "Jak vrátit zboží, které vám přišlo špatné",
      ],
    },
    {
      title: "Zálohování fotografií a vzpomínek",
      description: "Zajistíme, aby vaše cenné fotky nezmizely",
      icon: <Cloud className="w-8 h-8" />,
      category: "Domácnosti",
      details: [
        "Automatické zálohování fotek z telefonu",
        "Bezpečné ukládání na cloud (Google, OneDrive)",
        "Sdílení alb s rodinou bez rizika",
        "Obnovení fotek, které jste omylem smazali",
      ],
    },
    {
      title: "Nastavení chytrého domova",
      description: "Chytré zařízení, která vám usnadní život",
      icon: <Smartphone className="w-8 h-8" />,
      category: "Domácnosti",
      details: [
        "Chytré osvětlení, které se zapíná hlasem",
        "Termostat, který sám reguluje teplotu",
        "Bezpečnostní kamery a zvonky s videem",
        "Ovládání všeho z jedné aplikace",
      ],
    },
    {
      title: "Řešení problémů s WiFi a internetem",
      description: "Když internet nefunguje, víme co dělat",
      icon: <Zap className="w-8 h-8" />,
      category: "Domácnosti",
      details: [
        "Zrychlení pomalého internetu",
        "Oprava WiFi, která se stále odpojuje",
        "Bezpečné heslo k WiFi, aby se nikdo nepřipojil",
        "Pomoc s routerem a jeho nastavením",
      ],
    },
    {
      title: "Ochrana před podvody a phishingem",
      description: "Jak se chránit před online podvodníky",
      icon: <AlertTriangle className="w-8 h-8" />,
      category: "Domácnosti",
      details: [
        "Rozpoznání podvodných zpráv a e-mailů",
        "Bezpečná hesla, která si nemusíte pamatovat",
        "Dvoustupňové ověření pro důležité účty",
        "Co dělat, když vám někdo ukradl heslo",
      ],
    },
    {
      title: "Automatizace e-mailů a komunikace",
      description: "Ušetřete čas automatickými odpověďmi a workflows",
      icon: <Mail className="w-8 h-8" />,
      category: "Podnikatelé",
      details: [
        "Automatické odpovědi na běžné dotazy",
        "Hromadné e-maily s personalizací",
        "Integrace e-mailu s CRM systémem",
        "Naplánované e-maily pro kampaně",
      ],
    },
    {
      title: "Chatboti na webu (AI asistenti)",
      description: "Automatické odpovídání na dotazy zákazníků 24/7",
      icon: <MessageSquare className="w-8 h-8" />,
      category: "Podnikatelé",
      details: [
        "Chatbot, který odpovídá na běžné otázky",
        "Automatické sběr kontaktů od zájemců",
        "Integrace s vašim webem nebo Facebookem",
        "Přesměrování složitých dotazů na vás",
      ],
    },
    {
      title: "Analýza prodejů a dat",
      description: "Pochopte vaše data a rozhodujte lépe",
      icon: <BarChart3 className="w-8 h-8" />,
      category: "Podnikatelé",
      details: [
        "Přehledné grafy o vašich tržbách",
        "Která produkty se prodávají nejlépe",
        "Analýza chování vašich zákazníků",
        "Predikce trendů a plánování",
      ],
    },
    {
      title: "Zálohování firemních dat",
      description: "Vaše data jsou v bezpečí, vždy dostupná",
      icon: <HardDrive className="w-8 h-8" />,
      category: "Podnikatelé",
      details: [
        "Automatické zálohování všech souborů",
        "Obnovení dat v případě problému",
        "Bezpečný přístup z kanceláře i z domu",
        "Sdílení souborů s týmem bez rizika",
      ],
    },
    {
      title: "Správa sociálních sítí",
      description: "Naplánujte příspěvky a spravujte přítomnost online",
      icon: <Users className="w-8 h-8" />,
      category: "Podnikatelé",
      details: [
        "Naplánování příspěvků na týdny dopředu",
        "Automatické sdílení na více sítích",
        "Sledování, co o vás lidé říkají",
        "Analýza, které příspěvky fungují nejlépe",
      ],
    },
    {
      title: "Bezpečnost hesel a přístupu",
      description: "Ochrana vašeho podnikání před hackery",
      icon: <Lock className="w-8 h-8" />,
      category: "Podnikatelé",
      details: [
        "Správce hesel pro váš tým",
        "Dvoustupňové ověření pro důležité účty",
        "Kontrola, kdo má přístup k čemu",
        "Bezpečné mazání starých dat",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 z-50 bg-background/80 backdrop-blur-sm">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="heading text-xl font-bold">IT & AI Milovice</h1>
            </a>
          </Link>
          <Link href="/contact">
            <a>
              <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                Kontakt
              </Button>
            </a>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="container py-16">
        <h2 className="heading text-4xl font-bold mb-4">Naše služby</h2>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Kompletní nabídka IT a AI řešení pro domácnosti i podnikatele. Každá služba je navržena
          tak, aby vám ušetřila čas, peníze a starosti.
        </p>
      </section>

      {/* Services Grid */}
      <section className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, idx) => (
            <div
              key={idx}
              className="glow-card border-blue-500/20 hover:border-blue-400/60 p-6 transition-all duration-300"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="text-blue-400 mt-1">{service.icon}</div>
                <div>
                  <h3 className="heading font-bold text-lg mb-1">{service.title}</h3>
                  <p className="text-xs text-blue-400 font-semibold">{service.category}</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4 text-sm">{service.description}</p>
              <div className="space-y-2 mb-6">
                {service.details.map((detail, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="text-green-400 mt-1">✓</span>
                    <span>{detail}</span>
                  </div>
                ))}
              </div>
              <Link href="/contact">
                <a className="text-blue-400 hover:text-blue-300 text-sm font-semibold flex items-center gap-2 transition-colors">
                  Více informací <ArrowRight className="w-4 h-4" />
                </a>
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container py-16">
        <div className="glow-card border-green-500/30 hover:border-green-400/60 p-12 text-center">
          <h3 className="heading text-2xl font-bold mb-4">Máte otázku?</h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Kontaktujte nás a domluvte si bezplatnou konzultaci. Rádi vám pomůžeme vybrat
            správné řešení pro vaše potřeby.
          </p>
          <Link href="/contact">
            <a>
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Kontaktujte mě
              </Button>
            </a>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-16 py-8">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="heading font-bold mb-4">IT & AI Milovice</h4>
              <p className="text-sm text-muted-foreground">
                Vaš partner pro digitální transformaci
              </p>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Navigace</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/">
                    <a className="hover:text-foreground transition-colors">Domů</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <a className="hover:text-foreground transition-colors">Služby</a>
                  </Link>
                </li>
                <li>
                  <Link href="/blog">
                    <a className="hover:text-foreground transition-colors">Blog</a>
                  </Link>
                </li>
                <li>
                  <Link href="/contact">
                    <a className="hover:text-foreground transition-colors">Kontakt</a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Kontakt</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="tel:+420731253101" className="hover:text-foreground transition-colors">
                    731 253 101
                  </a>
                </li>
                <li>
                  <a href="mailto:petr.lukes89@gmail.com" className="hover:text-foreground transition-colors">
                    petr.lukes89@gmail.com
                  </a>
                </li>
                <li>
                  <a href="https://wa.me/420731253101" className="hover:text-foreground transition-colors">
                    WhatsApp
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Právní</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Zásady ochrany
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Podmínky použití
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 IT & AI Milovice. Všechna práva vyhrazena.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
