import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Zap, Phone, Mail, MessageCircle, CheckCircle } from "lucide-react";
import { useState } from "react";

/**
 * Contact - Stránka s kontaktním formulářem
 * Design: Futuristický minimalizmus s tmavým motivem
 * - Kontaktní údaje
 * - Kontaktní formulář
 * - FAQ
 */
export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const mailtoLink = `mailto:petr.lukes89@gmail.com?subject=Zpráva z webu&body=Jméno: ${formData.name}%0AEmail: ${formData.email}%0ATelefon: ${formData.phone}%0A%0AZpráva:%0A${formData.message}`;
    window.location.href = mailtoLink;
  };

  const faqs = [
    {
      question: "Jak dlouho trvá odpověď?",
      answer: "Na emaily odpovídáme do 24 hodin. Telefonní hovory řešíme okamžitě během pracovní doby.",
    },
    {
      question: "Jaké jsou vaše pracovní doby?",
      answer: "Pracujeme po-pá 9:00-17:00. V mimořádných případech je možné domluvit se i mimo tyto doby.",
    },
    {
      question: "Je konzultace opravdu zdarma?",
      answer: "Ano, konzultace je zcela zdarma a bez závazku. Bez skrytých poplatků.",
    },
    {
      question: "Jak se domluvíme schůzku?",
      answer: "Kontaktujte nás a domluvíme si čas, který vám vyhovuje. Schůzka může být osobně nebo online.",
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 z-50 bg-background/80 backdrop-blur-sm">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="heading text-xl font-bold">IT & AI Milovice</h1>
            </a>
          </Link>
          <Link href="/contact">
            <a>
              <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                Kontakt
              </Button>
            </a>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="container py-16">
        <h2 className="heading text-4xl font-bold mb-4">Kontaktujte nás</h2>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Jsme tu pro vás. Napište nám, zavolejte nebo nám pošlete zprávu přes WhatsApp.
          Odpovídáme rychle a rádi.
        </p>
      </section>

      {/* Contact Methods */}
      <section className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Phone */}
          <div className="glow-card border-blue-500/20 p-8 text-center">
            <Phone className="w-12 h-12 text-blue-400 mx-auto mb-4" />
            <h3 className="heading font-bold text-lg mb-2">Telefon</h3>
            <a
              href="tel:+420731253101"
              className="text-blue-400 hover:text-blue-300 font-semibold text-lg mb-2 block transition-colors"
            >
              731 253 101
            </a>
            <p className="text-sm text-muted-foreground">Po-Pá: 9:00 - 17:00</p>
          </div>

          {/* Email */}
          <div className="glow-card border-blue-500/20 p-8 text-center">
            <Mail className="w-12 h-12 text-blue-400 mx-auto mb-4" />
            <h3 className="heading font-bold text-lg mb-2">Email</h3>
            <a
              href="mailto:petr.lukes89@gmail.com"
              className="text-blue-400 hover:text-blue-300 font-semibold text-lg mb-2 block transition-colors break-all"
            >
              Petr.lukes89@gmail.com
            </a>
            <p className="text-sm text-muted-foreground">Odpověď do 24 hodin</p>
          </div>

          {/* WhatsApp */}
          <div className="glow-card border-blue-500/20 p-8 text-center">
            <MessageCircle className="w-12 h-12 text-blue-400 mx-auto mb-4" />
            <h3 className="heading font-bold text-lg mb-2">WhatsApp</h3>
            <a
              href="https://wa.me/420731253101"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 font-semibold text-lg mb-2 block transition-colors"
            >
              Napsat zprávu
            </a>
            <p className="text-sm text-muted-foreground">Okamžitá komunikace</p>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="container py-12">
        <div className="max-w-2xl mx-auto">
          <h3 className="heading text-2xl font-bold mb-8">Napište nám</h3>
          <form onSubmit={handleSubmit} className="glow-card border-blue-500/20 p-8 space-y-6">
            {/* Name */}
            <div>
              <label htmlFor="name" className="block text-sm font-semibold mb-2">
                Jméno <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                placeholder="Vaše jméno"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-semibold mb-2">
                Email <span className="text-red-400">*</span>
              </label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder="váš@email.com"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
              />
            </div>

            {/* Phone */}
            <div>
              <label htmlFor="phone" className="block text-sm font-semibold mb-2">
                Telefon
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                placeholder="731 253 101"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
              />
            </div>

            {/* Message */}
            <div>
              <label htmlFor="message" className="block text-sm font-semibold mb-2">
                Zpráva <span className="text-red-400">*</span>
              </label>
              <textarea
                id="message"
                name="message"
                placeholder="Popište váš problém nebo potřebu..."
                value={formData.message}
                onChange={handleChange}
                required
                rows={6}
                className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all resize-none"
              />
            </div>

            <Button type="submit" size="lg" className="w-full bg-blue-600 hover:bg-blue-700">
              Odeslat zprávu
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              <span className="text-red-400">*</span> Povinné pole
            </p>
          </form>

          <div className="mt-8 p-6 bg-blue-500/10 border border-blue-500/20 rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>Jak to funguje:</strong> Po kliknutí na "Odeslat zprávu" se otevře váš
              emailový klient s předvyplněnými údaji. Stačí kliknout "Odeslat" a vaše zpráva se
              dostane přímo na Petr.lukes89@gmail.com.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="container py-12">
        <h3 className="heading text-2xl font-bold mb-8">Časté otázky</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {faqs.map((faq, idx) => (
            <div key={idx} className="glow-card border-blue-500/20 p-6">
              <h4 className="heading font-bold mb-3">{faq.question}</h4>
              <p className="text-muted-foreground text-sm">{faq.answer}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-16 py-8">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="heading font-bold mb-4">IT & AI Milovice</h4>
              <p className="text-sm text-muted-foreground">
                Vaš partner pro digitální transformaci
              </p>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Navigace</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/">
                    <a className="hover:text-foreground transition-colors">Domů</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <a className="hover:text-foreground transition-colors">Služby</a>
                  </Link>
                </li>
                <li>
                  <Link href="/pricing">
                    <a className="hover:text-foreground transition-colors">Ceník</a>
                  </Link>
                </li>
                <li>
                  <Link href="/contact">
                    <a className="hover:text-foreground transition-colors">Kontakt</a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Domácnosti</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Podpora
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Bezpečnost
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Podnikatelé</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Zásady ochrany
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Podmínky použití
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 IT & AI Milovice. Všechna práva vyhrazena.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
