import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Zap, ArrowRight } from "lucide-react";

/**
 * Blog - Stránka s články a tipy
 * Design: Futuristický minimalizmus s tmavým motivem
 * - Seznam článků s datem a autorem
 * - Kategorie článků
 * - CTA pro kontakt
 */
export default function Blog() {
  const articles = [
    {
      id: 1,
      title: "ChatGPT pro domácnosti: 5 praktických tipů, které vám ušetří čas",
      excerpt: "Jak používat AI asistenty pro psaní emailů, plánování, učení a kreativní úkoly. Konkrétní příklady, které můžete hned zkoušet.",
      category: "AI pro domácnosti",
      date: "3. března 2026",
      author: "Petr Lukáš",
    },
    {
      id: 2,
      title: "AI pro podnikatele: Jak automatizovat emaily a ušetřit 10 hodin týdně",
      excerpt: "Konkrétní návod, jak nastavit automatické odpovědi, faktury a follow-upy. Příklady z reálného byznysu.",
      category: "AI pro podnikatele",
      date: "1. března 2026",
      author: "Petr Lukáš",
    },
    {
      id: 3,
      title: "Jak se zbavit pomalého počítače: Praktický průvodce čištěním",
      excerpt: "Krok za krokem návod, jak vyčistit počítač od prachu, malwaru a zbytečných souborů. Bez technického žargonu.",
      category: "IT pro domácnosti",
      date: "28. února 2026",
      author: "Petr Lukáš",
    },
    {
      id: 4,
      title: "Bezpečné zálohování dat: Jak neztratit své fotografie a dokumenty",
      excerpt: "Návod, jak nastavit automatické zálohování. Konkrétní služby a kroky, které zvládne každý.",
      category: "IT pro domácnosti",
      date: "25. února 2026",
      author: "Petr Lukáš",
    },
    {
      id: 5,
      title: "AI pro tvorbu obsahu: Jak ChatGPT pomáhá psát články, posty a emaily",
      excerpt: "Konkrétní tipy, jak používat AI na psaní. Od nápadů až po finální text.",
      category: "AI pro podnikatele",
      date: "22. února 2026",
      author: "Petr Lukáš",
    },
    {
      id: 6,
      title: "Bezpečnost hesel: Jak si vytvořit heslo, které si nemusíte pamatovat",
      excerpt: "Jednoduchý průvodce správcem hesel a bezpečností. Praktické tipy pro vás i vaši rodinu.",
      category: "IT pro domácnosti",
      date: "19. února 2026",
      author: "Petr Lukáš",
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 z-50 bg-background/80 backdrop-blur-sm">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="heading text-xl font-bold">IT & AI Milovice</h1>
            </a>
          </Link>
          <Link href="/contact">
            <a>
              <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                Kontakt
              </Button>
            </a>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="container py-16">
        <h2 className="heading text-4xl font-bold mb-4">Blog: Tipy a návody</h2>
        <p className="text-lg text-muted-foreground max-w-2xl">
          Přinášíme vám praktické články o tom, jak umělá inteligence a moderní IT řešení mohou
          konkrétně pomoci vám i vašemu podnikání. Vše je psáno srozumitelně, bez zbytečného
          technického žargonu – jen užitečné a praktické rady.
        </p>
      </section>

      {/* Articles Grid */}
      <section className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {articles.map((article) => (
            <article
              key={article.id}
              className="glow-card border-blue-500/20 hover:border-blue-400/60 p-6 transition-all duration-300"
            >
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs text-muted-foreground">{article.date}</span>
                <span className="text-xs text-muted-foreground">•</span>
                <span className="text-xs text-muted-foreground">{article.author}</span>
              </div>
              <h3 className="heading text-xl font-bold mb-3 leading-tight">
                {article.title}
              </h3>
              <p className="text-muted-foreground mb-4">{article.excerpt}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full">
                  {article.category}
                </span>
                <a href="#" className="text-blue-400 hover:text-blue-300 text-sm font-semibold flex items-center gap-2 transition-colors">
                  Číst více <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container py-16">
        <div className="glow-card border-green-500/30 hover:border-green-400/60 p-12 text-center">
          <h3 className="heading text-2xl font-bold mb-4">Máte otázku na AI nebo IT?</h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Přečtěte si naše články a najděte odpověď. Pokud ne, kontaktujte nás!
          </p>
          <Link href="/contact">
            <a>
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Napsat nám
              </Button>
            </a>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-16 py-8">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="heading font-bold mb-4">IT & AI Milovice</h4>
              <p className="text-sm text-muted-foreground">
                Vaš partner pro digitální transformaci
              </p>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Navigace</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/">
                    <a className="hover:text-foreground transition-colors">Domů</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <a className="hover:text-foreground transition-colors">Služby</a>
                  </Link>
                </li>
                <li>
                  <Link href="/blog">
                    <a className="hover:text-foreground transition-colors">Blog</a>
                  </Link>
                </li>
                <li>
                  <Link href="/contact">
                    <a className="hover:text-foreground transition-colors">Kontakt</a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Kontakt</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="tel:+420731253101" className="hover:text-foreground transition-colors">
                    731 253 101
                  </a>
                </li>
                <li>
                  <a href="mailto:petr.lukes89@gmail.com" className="hover:text-foreground transition-colors">
                    petr.lukes89@gmail.com
                  </a>
                </li>
                <li>
                  <a href="https://wa.me/420731253101" className="hover:text-foreground transition-colors">
                    WhatsApp
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Právní</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Zásady ochrany
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Podmínky použití
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 IT & AI Milovice. Všechna práva vyhrazena.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
