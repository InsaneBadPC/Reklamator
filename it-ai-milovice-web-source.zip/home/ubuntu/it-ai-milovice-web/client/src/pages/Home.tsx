import { Button } from "@/components/ui/button";
import ServiceCard from "@/components/ServiceCard";
import { Link } from "wouter";
import {
  Mail,
  Shield,
  HardDrive,
  Zap,
  BarChart3,
  Lock,
  Smartphone,
  AlertTriangle,
  MessageSquare,
  Users,
  Cloud,
  Settings,
} from "lucide-react";

/**
 * Home - Hlavní stránka IT & AI Milovice
 * Design: Futuristický minimalizmus s tmavým motivem
 * - Hero sekce s jasným CTA
 * - Interaktivní karty služeb s praktickými příklady
 * - Sekce pro domácnosti a podnikatele
 * - Srozumitelné texty bez technického žargonu
 */
export default function Home() {
  const servicesForHouseholds = [
    {
      title: "Pomoc s e-mailem a komunikací",
      description: "Nastavíme vám e-mail, vysvětlíme jak ho bezpečně používat",
      icon: <Mail className="w-6 h-6" />,
      examples: [
        "Nastavení e-mailu na telefonu a počítači",
        "Jak poznat podvodný e-mail a vyhnout se mu",
        "Bezpečné sdílení fotek s rodinou přes e-mail",
        "Organizace e-mailů do složek",
      ],
      color: "blue" as const,
    },
    {
      title: "Nákupy online bezpečně",
      description: "Naučíme vás bezpečně nakupovat na internetu",
      icon: <Shield className="w-6 h-6" />,
      examples: [
        "Jak poznat bezpečný e-shop a ověřit si ho",
        "Bezpečné platby kartou a přes PayPal",
        "Ochrana před podvody a padělky",
        "Jak vrátit zboží, které vám přišlo špatné",
      ],
      color: "green" as const,
    },
    {
      title: "Zálohování fotografií a vzpomínek",
      description: "Zajistíme, aby vaše cenné fotky nezmizely",
      icon: <Cloud className="w-6 h-6" />,
      examples: [
        "Automatické zálohování fotek z telefonu",
        "Bezpečné ukládání na cloud (Google, OneDrive)",
        "Sdílení alb s rodinou bez rizika",
        "Obnovení fotek, které jste omylem smazali",
      ],
      color: "purple" as const,
    },
    {
      title: "Nastavení chytrého domova",
      description: "Chytré zařízení, která vám usnadní život",
      icon: <Smartphone className="w-6 h-6" />,
      examples: [
        "Chytré osvětlení, které se zapíná hlasem",
        "Termostat, který sám reguluje teplotu",
        "Bezpečnostní kamery a zvonky s videem",
        "Ovládání všeho z jedné aplikace",
      ],
      color: "pink" as const,
    },
    {
      title: "Řešení problémů s WiFi a internetem",
      description: "Když internet nefunguje, víme co dělat",
      icon: <Zap className="w-6 h-6" />,
      examples: [
        "Zrychlení pomalého internetu",
        "Oprava WiFi, která se stále odpojuje",
        "Bezpečné heslo k WiFi, aby se nikdo nepřipojil",
        "Pomoc s routerem a jeho nastavením",
      ],
      color: "blue" as const,
    },
    {
      title: "Ochrana před podvody a phishingem",
      description: "Jak se chránit před online podvodníky",
      icon: <AlertTriangle className="w-6 h-6" />,
      examples: [
        "Rozpoznání podvodných zpráv a e-mailů",
        "Bezpečná hesla, která si nemusíte pamatovat",
        "Dvoustupňové ověření pro důležité účty",
        "Co dělat, když vám někdo ukradl heslo",
      ],
      color: "green" as const,
    },
  ];

  const servicesForEntrepreneurs = [
    {
      title: "Automatizace e-mailů a komunikace",
      description: "Ušetřete čas automatickými odpověďmi a workflows",
      icon: <Mail className="w-6 h-6" />,
      examples: [
        "Automatické odpovědi na běžné dotazy",
        "Hromadné e-maily s personalizací",
        "Integrace e-mailu s CRM systémem",
        "Naplánované e-maily pro kampaně",
      ],
      color: "blue" as const,
    },
    {
      title: "Chatboti na webu (AI asistenti)",
      description: "Automatické odpovídání na dotazy zákazníků 24/7",
      icon: <MessageSquare className="w-6 h-6" />,
      examples: [
        "Chatbot, který odpovídá na běžné otázky",
        "Automatické sběr kontaktů od zájemců",
        "Integrace s vašim webem nebo Facebookem",
        "Přesměrování složitých dotazů na vás",
      ],
      color: "green" as const,
    },
    {
      title: "Analýza prodejů a dat",
      description: "Pochopte vaše data a rozhodujte lépe",
      icon: <BarChart3 className="w-6 h-6" />,
      examples: [
        "Přehledné grafy o vašich tržbách",
        "Která produkty se prodávají nejlépe",
        "Analýza chování vašich zákazníků",
        "Predikce trendů a plánování",
      ],
      color: "purple" as const,
    },
    {
      title: "Zálohování firemních dat",
      description: "Vaše data jsou v bezpečí, vždy dostupná",
      icon: <HardDrive className="w-6 h-6" />,
      examples: [
        "Automatické zálohování všech souborů",
        "Obnovení dat v případě problému",
        "Bezpečný přístup z kanceláře i z domu",
        "Sdílení souborů s týmem bez rizika",
      ],
      color: "pink" as const,
    },
    {
      title: "Správa sociálních sítí",
      description: "Naplánujte příspěvky a spravujte přítomnost online",
      icon: <Users className="w-6 h-6" />,
      examples: [
        "Naplánování příspěvků na týdny dopředu",
        "Automatické sdílení na více sítích",
        "Sledování, co o vás lidé říkají",
        "Analýza, které příspěvky fungují nejlépe",
      ],
      color: "blue" as const,
    },
    {
      title: "Bezpečnost hesel a přístupu",
      description: "Ochrana vašeho podnikání před hackery",
      icon: <Lock className="w-6 h-6" />,
      examples: [
        "Správce hesel pro váš tým",
        "Dvoustupňové ověření pro důležité účty",
        "Kontrola, kdo má přístup k čemu",
        "Bezpečné mazání starých dat",
      ],
      color: "green" as const,
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 z-50 bg-background/80 backdrop-blur-sm">
        <div className="container py-4 flex items-center justify-between">
          <Link href="/">
            <a className="flex-shrink-0">
              <img src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663288606903/kgcuVVGopxPIoBBv.png" alt="Moderní Technologie Bez Vrásek" className="h-28 w-auto hover:opacity-90 transition-opacity" />
            </a>
          </Link>
          <Link href="/contact">
            <a>
              <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                Kontakt
              </Button>
            </a>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="max-w-4xl">
          <h2 className="heading text-5xl md:text-6xl font-bold mb-8 leading-tight tracking-tight">
            Technologie bez stresu
          </h2>
          <p className="text-xl text-muted-foreground mb-10 leading-relaxed font-light">
            Profesionální IT a AI podpora pro váš růst i klidný domov. Pomáháme malým
            podnikatelům a domácnostem ovládnout moderní nástroje bez technického
            žargonu a zbytečných složitostí.
          </p>
          <div className="flex gap-4">
            <Link href="/contact">
              <a>
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                  Domluvit konzultaci
                </Button>
              </a>
            </Link>
            <Link href="/services">
              <a>
                <Button size="lg" variant="outline" className="border-blue-500/30 hover:bg-blue-500/10">
                  Více informací
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Services for Households */}
      <section className="container py-16">
        <div className="mb-12">
          <h3 className="heading text-3xl font-bold mb-2">Služby pro domácnosti</h3>
          <p className="text-muted-foreground">
            Spolehlivý IT expert po ruce. Postaráme se o nastavení vašich zařízení,
            jejich bezpečnost a veškerou technickou podporu.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicesForHouseholds.map((service, idx) => (
            <ServiceCard key={idx} {...service} />
          ))}
        </div>
      </section>

      {/* Services for Entrepreneurs */}
      <section className="container py-16">
        <div className="mb-12">
          <h3 className="heading text-3xl font-bold mb-2">Služby pro podnikatele</h3>
          <p className="text-muted-foreground">
            Digitální transformace a AI pro váš růst. Pomůžeme vám integrovat
            umělou inteligenci a automatizaci do vašeho podnikání.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicesForEntrepreneurs.map((service, idx) => (
            <ServiceCard key={idx} {...service} />
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-16">
        <div className="glow-card border-green-500/30 hover:border-green-400/60 p-12 text-center">
          <h3 className="heading text-2xl font-bold mb-4">
            Jste připraveni na změnu?
          </h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Ozvěte se nám ještě dnes a domluvte si bezplatnou a nezávaznou konzultaci.
            Společně najdeme to nejlepší řešení pro vás.
          </p>
          <Link href="/contact">
            <a>
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Kontaktujte mě
              </Button>
            </a>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-16 py-8">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="heading font-bold mb-4">IT & AI Milovice</h4>
              <p className="text-sm text-muted-foreground">
                Vaš partner pro digitální transformaci
              </p>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Navigace</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/">
                    <a className="hover:text-foreground transition-colors">Domů</a>
                  </Link>
                </li>
                <li>
                  <Link href="/services">
                    <a className="hover:text-foreground transition-colors">Služby</a>
                  </Link>
                </li>
                <li>
                  <Link href="/process">
                    <a className="hover:text-foreground transition-colors">Jak to funguje</a>
                  </Link>
                </li>
                <li>
                  <Link href="/pricing">
                    <a className="hover:text-foreground transition-colors">Ceník</a>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Kontakt</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="tel:+420731253101" className="hover:text-foreground transition-colors">731 253 101</a></li>
                <li><a href="mailto:petr.lukes89@gmail.com" className="hover:text-foreground transition-colors">petr.lukes89@gmail.com</a></li>
                <li><a href="https://wa.me/420731253101" className="hover:text-foreground transition-colors">WhatsApp</a></li>
              </ul>
            </div>
            <div>
              <h4 className="heading font-bold mb-4">Právní</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Zásady ochrany</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Podmínky použití</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 IT & AI Milovice. Všechna práva vyhrazena.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
