import { ChevronDown } from "lucide-react";
import { useState } from "react";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  examples: string[];
  color?: "blue" | "green" | "purple" | "pink";
}

const colorClasses = {
  blue: "border-blue-500/30 hover:border-blue-400/60 hover:shadow-blue-500/20",
  green: "border-green-500/30 hover:border-green-400/60 hover:shadow-green-500/20",
  purple: "border-purple-500/30 hover:border-purple-400/60 hover:shadow-purple-500/20",
  pink: "border-pink-500/30 hover:border-pink-400/60 hover:shadow-pink-500/20",
};

const accentColors = {
  blue: "text-blue-400",
  green: "text-green-400",
  purple: "text-purple-400",
  pink: "text-pink-400",
};

/**
 * ServiceCard - Interaktivní karta služby s rozbalovacím obsahem
 * Design: Futuristický minimalizmus s glowing efekty
 * - Hover: Karta se zvedá a svítí
 * - Click: Rozbalí se praktické příklady
 * - Animace: Plynulé přechody a efekty
 */
export default function ServiceCard({
  title,
  description,
  icon,
  examples,
  color = "blue",
}: ServiceCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div
      className={`glow-card group cursor-pointer overflow-hidden transition-all duration-300 ${colorClasses[color]}`}
      onClick={() => setIsExpanded(!isExpanded)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          setIsExpanded(!isExpanded);
        }
      }}
    >
      {/* Hlavička karty */}
      <div className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className={`mb-3 inline-block p-2 rounded-lg bg-${color}-500/10`}>
              <div className={`${accentColors[color]} text-2xl transition-transform duration-300 group-hover:scale-110`}>
                {icon}
              </div>
            </div>
            <h3 className="heading text-xl font-bold text-foreground mb-2">
              {title}
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {description}
            </p>
          </div>
          <div
            className={`ml-4 transition-transform duration-300 ${
              isExpanded ? "rotate-180" : ""
            }`}
          >
            <ChevronDown className={`${accentColors[color]} w-5 h-5`} />
          </div>
        </div>
      </div>

      {/* Rozbalovací obsah s příklady */}
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isExpanded ? "max-h-96" : "max-h-0"
        }`}
      >
        <div className="px-6 pb-6 border-t border-border/50">
          <div className="mt-4">
            <p className="text-xs font-semibold text-accent mb-3 uppercase tracking-wider">
              Praktické příklady:
            </p>
            <ul className="space-y-2">
              {examples.map((example, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <span className={`${accentColors[color]} font-bold mt-0.5 flex-shrink-0`}>
                    •
                  </span>
                  <span>{example}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
